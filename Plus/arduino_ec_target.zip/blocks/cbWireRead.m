function cbWireRead(block)
% Copyright 1994-2014 The MathWorks, Inc.

mask_state = get_param(block, 'MaskEnables');
mask_visi = get_param(block, 'MaskVisibilities'); 

if strcmp(get_param(block, 'Master'), 'Master')
    for i=[2 4]
        mask_state{i} = 'on';
        mask_visi{i} = 'on';
    end
else
    for i=[2 4]                     % 2 -> address, 4 -> command
        mask_state{i} = 'off';
        mask_visi{i} = 'off';
    end
end
set_param(block, 'MaskEnables', mask_state);
set_param(block, 'MaskVisibilities', mask_visi); 

end
