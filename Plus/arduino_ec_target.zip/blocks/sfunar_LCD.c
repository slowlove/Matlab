/* Copyright 2013-2014 The MathWorks, Inc. */
/*
 *   sfunar_LCD.c
 *
 *   ABSTRACT:
 *     The purpose of this sfunction is to call a LCD Class.
 *
 */

/* Parameters */
enum {  COL_ROW = 0,
        PINS,
        INPUTS,
        STARTUPTEXT,
        DELAY,
        EFFECTS,
        SAMPLE_TIME,

        CURSOR1,
        CURSOR2,
        CURSOR3,
        CURSOR4,

        POSTEXT1,
        POSTEXT2,
        POSTEXT3,
        POSTEXT4,

        FORMAT1,
        FORMAT2,
        FORMAT3,
        FORMAT4,

        N_PARAMS
};

/*
 * Must specify the S_FUNCTION_NAME as the name of the S-function.
 */
#define S_FUNCTION_NAME                sfunar_LCD
#define S_FUNCTION_LEVEL               2

/*
 * Need to include simstruc.h for the definition of the SimStruct and
 * its associated macro definitions.
 */
#include "simstruc.h"
#define EDIT_OK(S, P_IDX) \
 (!((ssGetSimMode(S)==SS_SIMMODE_SIZES_CALL_ONLY) && mxIsEmpty(ssGetSFcnParam(S, P_IDX))))

/*
 * Utility function prototypes.
 */
static bool IsRealMatrix(const mxArray * const m);


#define MDL_CHECK_PARAMETERS
#if defined(MDL_CHECK_PARAMETERS) && defined(MATLAB_MEX_FILE)

/* Function: mdlCheckParameters ===========================================
 * Abstract:
 *    mdlCheckParameters verifies new parameter settings whenever parameter
 *    change or are re-evaluated during a simulation. When a simulation is
 *    running, changes to S-function parameters can occur at any time during
 *    the simulation loop.
 */
static void mdlCheckParameters(SimStruct *S)
{
  /*
   * Check the parameter COL_ROW
   */
  if EDIT_OK(S, COL_ROW) {
    int_T *dimsArray = (int_T *) mxGetDimensions(ssGetSFcnParam(S, COL_ROW));

    /* Parameter COL_ROW must be a vector */
    if ((dimsArray[0] > 1) && (dimsArray[1] > 1)) {
      ssSetErrorStatus(S,"Parameter COL_ROW must be a vector");
      return;
    }

    /* Parameter COL_ROW must have 2 elements */
    if (mxGetNumberOfElements(ssGetSFcnParam(S, COL_ROW)) != 2) {
      ssSetErrorStatus(S,"Parameter COL_ROW must have 2 elements");
      return;
    }

    /* Check the parameter attributes */
    ssCheckSFcnParamValueAttribs(S, COL_ROW, "P1", DYNAMICALLY_TYPED, 2, dimsArray, 0);
  }

  /*
   * Check the parameter PINS
   */
  if EDIT_OK(S, PINS) {
    int_T *dimsArray = (int_T *) mxGetDimensions(ssGetSFcnParam(S, PINS));

    /* Parameter PINS must be a vector */
    if ((dimsArray[0] > 1) && (dimsArray[1] > 1)) {
      ssSetErrorStatus(S,"Parameter PINS must be a vector");
      return;
    }

    if (mxGetNumberOfElements(ssGetSFcnParam(S, PINS)) > 12){
      ssSetErrorStatus(S,"Parameter PINS can have up 12 elements");
      return;
    }

    /* Check the parameter attributes */
    ssCheckSFcnParamValueAttribs(S, PINS, "P2", DYNAMICALLY_TYPED, 2, dimsArray, 0);
  }

  /*
   * Check the parameter INPUTS
   */
  if EDIT_OK(S, INPUTS) {
    int_T dimsArray[2] = { 1, 1 };

    /* Check the parameter attributes */
    ssCheckSFcnParamValueAttribs(S, INPUTS, "P3", DYNAMICALLY_TYPED, 2, dimsArray, 0);
  }

  /*
   * Check the parameter DELAY
   */
  if EDIT_OK(S, DELAY) {
    int_T *dimsArray = (int_T *) mxGetDimensions(ssGetSFcnParam(S, DELAY));

#if 0
    /* Parameter 4 must be a vector */
    if ((dimsArray[0] > 1) && (dimsArray[1] > 1)) {
      ssSetErrorStatus(S,"Parameter DELAY must be a vector");
      return;
    }
#endif

    /* Check the parameter attributes */
    ssCheckSFcnParamValueAttribs(S, DELAY, "P4", DYNAMICALLY_TYPED, 2, dimsArray, 0);
  }



  /*
   * Check the parameter 2 (sample time)
   */
  if EDIT_OK(S, SAMPLE_TIME) {
    const real_T *sampleTime = NULL;
    const size_t stArraySize = mxGetM(ssGetSFcnParam(S,SAMPLE_TIME)) * mxGetN(ssGetSFcnParam(S,SAMPLE_TIME));

    /* Sample time must be a real scalar value or 2 element array. */
    if (IsRealMatrix(ssGetSFcnParam(S,SAMPLE_TIME)) &&
        (stArraySize == 1 || stArraySize == 2) ) {
      sampleTime = (real_T *) mxGetPr(ssGetSFcnParam(S,SAMPLE_TIME));
    } else {
      ssSetErrorStatus(S,
                       "Invalid sample time. Sample time must be a real scalar value or an array of two real values.");
      return;
    }

    if (sampleTime[0] < 0.0 && sampleTime[0] != -1.0) {
      ssSetErrorStatus(S,
                       "Invalid sample time. Period must be non-negative or -1 (for inherited).");
      return;
    }

    if (stArraySize == 2 && sampleTime[0] > 0.0 &&
        sampleTime[1] >= sampleTime[0]) {
      ssSetErrorStatus(S,
                       "Invalid sample time. Offset must be smaller than period.");
      return;
    }

    if (stArraySize == 2 && sampleTime[0] == -1.0 && sampleTime[1] != 0.0) {
      ssSetErrorStatus(S,
                       "Invalid sample time. When period is -1, offset must be 0.");
      return;
    }

    if (stArraySize == 2 && sampleTime[0] == 0.0 &&
        !(sampleTime[1] == 1.0)) {
      ssSetErrorStatus(S,
                       "Invalid sample time. When period is 0, offset must be 1.");
      return;
    }
  }



  /*
   * Check the parameter CURSOR1
   */
  if EDIT_OK(S, CURSOR1) {
    int_T *dimsArray = (int_T *) mxGetDimensions(ssGetSFcnParam(S, CURSOR1));

    /* Parameter CURSOR1 must be a vector */
    if ((dimsArray[0] > 1) && (dimsArray[1] > 1)) {
      ssSetErrorStatus(S,"Parameter CURSOR1 must be a vector");
      return;
    }

    /* Parameter CURSOR1 must have 2 elements or 3 elements */
    if ((mxGetNumberOfElements(ssGetSFcnParam(S, CURSOR1)) != 2) && mxGetNumberOfElements(ssGetSFcnParam(S, CURSOR1)) != 3 ){
      ssSetErrorStatus(S,"Parameter CURSOR1 must have 2 or 3 elements");
      return;
    }

    /* Check the parameter attributes */
    ssCheckSFcnParamValueAttribs(S, CURSOR1, "P5", DYNAMICALLY_TYPED, 2, dimsArray, 0);
 }

  /*
   * Check the parameter CURSOR2
   */
  if EDIT_OK(S, CURSOR2) {
    int_T *dimsArray = (int_T *) mxGetDimensions(ssGetSFcnParam(S, CURSOR2));

    /* Parameter CURSOR2 must be a vector */
    if ((dimsArray[0] > 1) && (dimsArray[1] > 1)) {
      ssSetErrorStatus(S,"Parameter CURSOR2 must be a vector");
      return;
    }

    /* Parameter CURSOR2 must have 2 elements or 3 elements */
    if ((mxGetNumberOfElements(ssGetSFcnParam(S, CURSOR2)) != 2) && mxGetNumberOfElements(ssGetSFcnParam(S, CURSOR2)) != 3 ){
      ssSetErrorStatus(S,"Parameter CURSOR2 must have 2 or 3 elements");
      return;
    }

    /* Check the parameter attributes */
    ssCheckSFcnParamValueAttribs(S, CURSOR2, "P6", DYNAMICALLY_TYPED, 2, dimsArray, 0);
  }

  /*
   * Check the parameter CURSOR3
   */
  if EDIT_OK(S, CURSOR3) {
    int_T *dimsArray = (int_T *) mxGetDimensions(ssGetSFcnParam(S, CURSOR3));

    /* Parameter CURSOR3 must be a vector */
    if ((dimsArray[0] > 1) && (dimsArray[1] > 1)) {
      ssSetErrorStatus(S,"Parameter CURSOR3 must be a vector");
      return;
    }

    /* Parameter CURSOR3 must have 2 elements or 3 elements */
    if ((mxGetNumberOfElements(ssGetSFcnParam(S, CURSOR3)) != 2) && mxGetNumberOfElements(ssGetSFcnParam(S, CURSOR3)) != 3 ){
      ssSetErrorStatus(S,"Parameter CURSOR3 must have 2 or 3 elements");
      return;
    }

    /* Check the parameter attributes */
    ssCheckSFcnParamValueAttribs(S, CURSOR3, "P7", DYNAMICALLY_TYPED, 2, dimsArray, 0);
  }

  /*
   * Check the parameter CURSOR4
   */
  if EDIT_OK(S, CURSOR4) {
    int_T *dimsArray = (int_T *) mxGetDimensions(ssGetSFcnParam(S, CURSOR4));

    /* Parameter CURSOR4 must be a vector */
    if ((dimsArray[0] > 1) && (dimsArray[1] > 1)) {
      ssSetErrorStatus(S,"Parameter CURSOR4 must be a vector");
      return;
    }

    /* Parameter CURSOR4 must have 2 elements or 3 elements */
    if ((mxGetNumberOfElements(ssGetSFcnParam(S, CURSOR4)) != 2) && mxGetNumberOfElements(ssGetSFcnParam(S, CURSOR4)) != 3 ){
      ssSetErrorStatus(S,"Parameter CURSOR4 must have 2 or 3 elements");
      return;
    }

    /* Check the parameter attributes */
    ssCheckSFcnParamValueAttribs(S, CURSOR3, "P8", DYNAMICALLY_TYPED, 2, dimsArray, 0);
  }

}
#endif

/* Function: mdlInitializeSizes ===========================================
 * Abstract:
 *    The sizes information is used by Simulink to determine the S-function
 *    block's characteristics (number of inputs, outputs, states, etc.).
 */
static void mdlInitializeSizes(SimStruct *S)
{
   int32_T i, n, effects;

  /* Number of expected parameters */
  ssSetNumSFcnParams(S, N_PARAMS);

#if defined(MATLAB_MEX_FILE)

  if (ssGetNumSFcnParams(S) == ssGetSFcnParamsCount(S)) {
    /*
     * If the number of expected input parameters is not equal
     * to the number of parameters entered in the dialog box return.
     * Simulink will generate an error indicating that there is a
     * parameter mismatch.
     */
    mdlCheckParameters(S);
    if (ssGetErrorStatus(S) != NULL) {
      return;
    }
  } else {
    /* Return if number of expected != number of actual parameters */
    return;
  }

#endif

  /* Set the parameter's tunability */
  for(i=0;i<N_PARAMS;i++)
  {
    ssSetSFcnParamTunable(S, i, SS_PRM_NOT_TUNABLE);
  }

  /*
   * Set the number of pworks.
   */
  ssSetNumPWork(S, 0);

  /*
   * Set the number of dworks.
   */
  if (!ssSetNumDWork(S, 0))
    return;

    /*
   * Set the number of input ports.
   */
  n = (int32_T) mxGetPr(ssGetSFcnParam(S,INPUTS))[0];
  effects = (uint8_T) mxGetPr(ssGetSFcnParam(S,EFFECTS))[0];

  if (!ssSetNumInputPorts(S, n + effects))
    return;

  /*
   * Configure the input ports
   */
  for(i=0;i<n;i++)
  {
      ssSetInputPortDataType            (S, i, DYNAMICALLY_TYPED);
      ssSetInputPortWidth               (S, i, 1);
      ssSetInputPortComplexSignal       (S, i, COMPLEX_NO);
      ssSetInputPortDirectFeedThrough   (S, i, 1);
      ssSetInputPortAcceptExprInRTW     (S, i, 1);
      ssSetInputPortOverWritable        (S, i, 1);
      ssSetInputPortOptimOpts           (S, i, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortRequiredContiguous  (S, i, 1);
  }

  if(effects != 0)
  {
      ssSetInputPortDataType            (S, n, SS_UINT8);
      ssSetInputPortWidth               (S, n, 1);
      ssSetInputPortComplexSignal       (S, n, COMPLEX_NO);
      ssSetInputPortDirectFeedThrough   (S, n, 1);
      ssSetInputPortAcceptExprInRTW     (S, n, 1);
      ssSetInputPortOverWritable        (S, n, 1);
      ssSetInputPortOptimOpts           (S, n, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortRequiredContiguous  (S, n, 1);
  }

  /*
   * Set the number of output ports.
   */
  if (!ssSetNumOutputPorts(S, 0))
    return;

  /*
   * Register reserved identifiers to avoid name conflict
   */
  if (ssRTWGenIsCodeGen(S) || ssGetSimMode(S)==SS_SIMMODE_EXTERNAL) {
    /*
     * Register reserved identifier for StartFcnSpec
     */
    ssRegMdlInfo(S, "LCD", MDL_INFO_ID_RESERVED, 0, 0, ssGetPath(S));
  }

  /*
   * This S-function can be used in referenced model simulating in normal mode.
   */
  ssSetModelReferenceNormalModeSupport(S, MDL_START_AND_MDL_PROCESS_PARAMS_OK);

  /*
   * Set the number of sample time.
   */
  ssSetNumSampleTimes(S, 1);

  /*
   * All options have the form SS_OPTION_<name> and are documented in
   * matlabroot/simulink/include/simstruc.h. The options should be
   * bitwise or'd together as in
   *   ssSetOptions(S, (SS_OPTION_name1 | SS_OPTION_name2))
   */
  ssSetOptions(S,
               SS_OPTION_USE_TLC_WITH_ACCELERATOR |
               SS_OPTION_CAN_BE_CALLED_CONDITIONALLY |
               SS_OPTION_EXCEPTION_FREE_CODE |
               SS_OPTION_WORKS_WITH_CODE_REUSE |
               SS_OPTION_SFUNCTION_INLINED_FOR_RTW |
               SS_OPTION_DISALLOW_CONSTANT_SAMPLE_TIME);
}

/* Function: mdlInitializeSampleTimes =====================================
 * Abstract:
 *    This function is used to specify the sample time(s) for your
 *    S-function. You must register the same number of sample times as
 *    specified in ssSetNumSampleTimes.
 */
static void mdlInitializeSampleTimes(SimStruct *S)
{
  const real_T * const sampleTime = (real_T*) (mxGetPr(ssGetSFcnParam(S,SAMPLE_TIME)));
  const size_t stArraySize = mxGetM(ssGetSFcnParam(S,SAMPLE_TIME)) * mxGetN(ssGetSFcnParam(S,SAMPLE_TIME));

  ssSetSampleTime(S, 0, sampleTime[0]);
  if (stArraySize == 1) {
    ssSetOffsetTime(S, 0, (sampleTime[0] == CONTINUOUS_SAMPLE_TIME?
      FIXED_IN_MINOR_STEP_OFFSET: 0.0));
  } else {
    ssSetOffsetTime(S, 0, sampleTime[1]);
  }

#if defined(ssSetModelReferenceSampleTimeDefaultInheritance)

  ssSetModelReferenceSampleTimeDefaultInheritance(S);

#endif
}

#define MDL_SET_WORK_WIDTHS
#if defined(MDL_SET_WORK_WIDTHS) && defined(MATLAB_MEX_FILE)

/* Function: mdlSetWorkWidths =============================================
 * Abstract:
 *      The optional method, mdlSetWorkWidths is called after input port
 *      width, output port width, and sample times of the S-function have
 *      been determined to set any state and work vector sizes which are
 *      a function of the input, output, and/or sample times.
 *
 *      Run-time parameters are registered in this method using methods
 *      ssSetNumRunTimeParams, ssSetRunTimeParamInfo, and related methods.
 */
static void mdlSetWorkWidths(SimStruct *S)
{
  /* Set number of run-time parameters */
  if (!ssSetNumRunTimeParams(S, N_PARAMS))
    return;
}

#endif

#define MDL_START
#if defined(MDL_START)

/* Function: mdlStart =====================================================
 * Abstract:
 *    This function is called once at start of model execution. If you
 *    have states that should be initialized once, this is the place
 *    to do it.
 */
static void mdlStart(SimStruct *S)
{
}

#endif

/* Function: mdlOutputs ===================================================
 * Abstract:
 *    In this function, you compute the outputs of your S-function
 *    block. Generally outputs are placed in the output vector(s),
 *    ssGetOutputPortSignal.
 */
static void mdlOutputs(SimStruct *S, int_T tid)
{
  /*
   * Get access to Parameter/Input/Output/DWork/size information
   */
}

/* Function: mdlTerminate =================================================
 * Abstract:
 *    In this function, you should perform any actions that are necessary
 *    at the termination of a simulation.
 */
static void mdlTerminate(SimStruct *S)
{
}

#define MDL_RTW
void mdlRTW(SimStruct *S)
{
   int_T i;
   uint8_T col      = (uint8_T) mxGetPr(ssGetSFcnParam(S,COL_ROW))[0];
   uint8_T row      = (uint8_T) mxGetPr(ssGetSFcnParam(S,COL_ROW))[1];
   uint8_T inputs   = (uint8_T) mxGetPr(ssGetSFcnParam(S,INPUTS))[0];
   uint16_T delay   = (uint16_T)mxGetPr(ssGetSFcnParam(S,DELAY))[0];
   uint8_T effects  = (uint8_T) mxGetPr(ssGetSFcnParam(S,EFFECTS))[0];
   uint8_T  cursor[4][3];
   uint8_T  postext[4][2];

   uint8_T  pins[16];

    for(i=0;i<mxGetNumberOfElements(ssGetSFcnParam(S,PINS));i++)
    {
        pins[i] = (uint8_T) mxGetPr(ssGetSFcnParam(S,PINS))[i];
    }

    for(i=0;i<4;i++)
    {
        cursor[i][0] = (uint8_T) mxGetPr(ssGetSFcnParam(S,CURSOR1 + i))[0];
        cursor[i][1] = (uint8_T) mxGetPr(ssGetSFcnParam(S,CURSOR1 + i))[1];
        if (mxGetNumberOfElements(ssGetSFcnParam(S, CURSOR1 + i)) == 3) {
            cursor[i][2] = (uint8_T) mxGetPr(ssGetSFcnParam(S,CURSOR1 + i))[2];
        }
        else
        {
            cursor[i][2] = 0;
        }
    }

    for(i=0;i<4;i++)
    {
        postext[i][0] = (uint8_T) mxGetPr(ssGetSFcnParam(S,POSTEXT1 + i))[0];
        postext[i][1] = (uint8_T) mxGetPr(ssGetSFcnParam(S,POSTEXT1 + i))[1];
    }

    if (!ssWriteRTWParamSettings(S, 19,
           SSWRITE_VALUE_DTYPE_NUM,  "col",        &col, DTINFO(SS_UINT8, COMPLEX_NO),
           SSWRITE_VALUE_DTYPE_NUM,  "row",        &row, DTINFO(SS_UINT8, COMPLEX_NO),

           SSWRITE_VALUE_DTYPE_VECT, "pins",       pins,  mxGetNumberOfElements(ssGetSFcnParam(S, PINS)),
                                                   DTINFO(SS_UINT8, COMPLEX_NO),

           SSWRITE_VALUE_DTYPE_NUM,  "inputs",     &inputs, DTINFO(SS_UINT8, COMPLEX_NO),
           SSWRITE_VALUE_STR,        "startuptext",mxArrayToString(ssGetSFcnParam(S,STARTUPTEXT)),
           SSWRITE_VALUE_DTYPE_NUM,  "delay",      &delay, DTINFO(SS_UINT16, COMPLEX_NO),

           SSWRITE_VALUE_DTYPE_NUM,  "effects",    &effects, DTINFO(SS_UINT8, COMPLEX_NO),

           SSWRITE_VALUE_DTYPE_VECT, "cursor1",    cursor[0], 3, DTINFO(SS_UINT8, COMPLEX_NO),
           SSWRITE_VALUE_DTYPE_VECT, "cursor2",    cursor[1], 3, DTINFO(SS_UINT8, COMPLEX_NO),
           SSWRITE_VALUE_DTYPE_VECT, "cursor3",    cursor[2], 3, DTINFO(SS_UINT8, COMPLEX_NO),
           SSWRITE_VALUE_DTYPE_VECT, "cursor4",    cursor[3], 3, DTINFO(SS_UINT8, COMPLEX_NO),

           SSWRITE_VALUE_DTYPE_VECT, "postext1",   postext[0], 2, DTINFO(SS_UINT8, COMPLEX_NO),
           SSWRITE_VALUE_DTYPE_VECT, "postext2",   postext[1], 2, DTINFO(SS_UINT8, COMPLEX_NO),
           SSWRITE_VALUE_DTYPE_VECT, "postext3",   postext[2], 2, DTINFO(SS_UINT8, COMPLEX_NO),
           SSWRITE_VALUE_DTYPE_VECT, "postext4",   postext[3], 2, DTINFO(SS_UINT8, COMPLEX_NO),

           SSWRITE_VALUE_STR,        "format1",    mxArrayToString(ssGetSFcnParam(S,FORMAT1)),
           SSWRITE_VALUE_STR,        "format2",    mxArrayToString(ssGetSFcnParam(S,FORMAT2)),
           SSWRITE_VALUE_STR,        "format3",    mxArrayToString(ssGetSFcnParam(S,FORMAT3)),
           SSWRITE_VALUE_STR,        "format4",    mxArrayToString(ssGetSFcnParam(S,FORMAT4))

           ))
    {
            ssSetErrorStatus(S,"ssWriteRTWParamSettings error in mdlRTW");
    }
}

/* Function: IsRealMatrix =================================================
 * Abstract:
 *      Verify that the mxArray is a real (double) finite matrix
 */
static bool IsRealMatrix(const mxArray * const m)
{
  if (mxIsNumeric(m) &&
      mxIsDouble(m) &&
      !mxIsLogical(m) &&
      !mxIsComplex(m) &&
      !mxIsSparse(m) &&
      !mxIsEmpty(m) &&
      mxGetNumberOfDimensions(m) == 2) {
    const real_T * const data = mxGetPr(m);
    const size_t numEl = mxGetNumberOfElements(m);
    size_t i;
    for (i = 0; i < numEl; i++) {
      if (!mxIsFinite(data[i])) {
        return(false);
      }
    }

    return(true);
  } else {
    return(false);
  }
}

/*
 * Required S-function trailer
 */
#ifdef MATLAB_MEX_FILE
# include "simulink.c"
#else
# include "cg_sfun.h"
#endif
