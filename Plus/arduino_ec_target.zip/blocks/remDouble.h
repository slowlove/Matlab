/*  This undef removes double re-redinition in External Mode Integer only
 * Copyright 2002-2014 The MathWorks, Inc.
 */
#undef double
