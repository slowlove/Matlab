/* Copyright 1994-2014 The MathWorks, Inc. */

#ifndef __MW_servo_h__
#define __MW_servo_h__

#ifdef __cplusplus
extern "C" { 
#endif        
  void MW_servoAttach(uint8_t  servo, uint8_t pinNumber);
  void MW_servoWrite(uint8_t servo, uint8_t inValue);
#ifdef __cplusplus
}
#endif        

#endif  /* __MW_servo_h__ */
