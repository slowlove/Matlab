/* Copyright 1994-2014 The MathWorks, Inc. */

#include "rtwtypes.h"

#include "Arduino.h"
#include "Servo.h"
#include "MW_Servo.h"

static Servo servoPool[2];

void MW_servoAttach(uint8_t servo, uint8_t pinNumber)
{
 	servoPool[servo].attach(pinNumber);
}


void MW_servoWrite(uint8_t servo, uint8_t inValue)
{
    servoPool[servo].write(inValue);
}


