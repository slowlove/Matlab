% This script buils all demos
%  Copyright 2012-2014 The MathWorks, Inc. 

cd demos
list = [dir('*.mdl'); dir('*.slx')];

for i = 1:numel(list)
    [~,file,~] = fileparts(list(i).name);
    fprintf('\n\n########### Building model %s #######################\n\n', file);
    load_system(file);

    set_param(file, 'LaunchReport',         'off');
    set_param(file, 'DownloadToArduino',    'off');
    %set_param(file, 'PurelyIntegerCode',    'on');
    %set_param(file, 'ParallelExecution',    'on');
    %set_param(file, 'AlternativeGCC',       'c:\Apps\avr-gcc-4.8-mingw32\bin');
    %set_param(file, 'DialogOptions',        '-O2 -flto');

    % Build it as C
    % Most of the demos need C++, so skip it
    %set_param(file, 'TargetLang', 'C');
    %try
    %    rtwbuild(bdroot)
    %catch
    %end

    % Build it as C++
    set_param(file, 'TargetLang', 'C++');
    try
        if exist('slprj', 'dir')
            rmdir('slprj', 's');
        end
        rtwbuild(bdroot)
    catch
        fprintf('Building of %s failed.\n', bdroot);
    end

    bdclose
end

cd ..
