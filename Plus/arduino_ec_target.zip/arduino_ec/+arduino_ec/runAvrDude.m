function runAvrDude(hexFile)
%RUNAVRDUDE downloads a program into flash using avrdude
    
%   Copyright 2009-2014 The MathWorks, Inc.
    
    persistent lastComPort;
    persistent lastHexContent;
    
    hexContent = fileread(hexFile);
    avrdude_port = arduino_ec.Prefs.getComPort;
    needDownload = ...
        isempty(lastHexContent) || ...
        isempty(lastComPort) || ...
        ~strcmp(hexContent, lastHexContent) || ...
        ~strcmp(avrdude_port, lastComPort);
    
    if needDownload
        [hexDir,hexFile,hexExt]=fileparts(hexFile);
        hexFile = [hexFile hexExt];
        arduinoPath = arduino_ec.Prefs.getArduinoPath;
        avrPath=fullfile(arduinoPath,'hardware','tools','avr');
        avrPath=strrep(avrPath,'\','/');

        avrdude_conf = sprintf('%s/etc/avrdude.conf', avrPath);
        avrdude_programmer = arduino_ec.Prefs.getProgrammer;
        avrdude =  sprintf('%s/bin/avrdude', avrPath);
        mcu = arduino_ec.Prefs.getMCU;
        uploadRate = arduino_ec.Prefs.getUploadRate;

        % Leonardo has special flash procedure
        origPort = avrdude_port;
        if strcmp(arduino_ec.Prefs.getBoard, 'leonardo')
            Reset1200(avrdude_port);
            % Wait until reset proceeds
            fprintf('### Reset proceeded, searching Leonardo''s bootloader, please wait ....\n');
            % Wait for USB renumeration
            pause(3);
            % After Reset, Leonardo's bootoader waits 8 seconds on
            % different COM port for flashing
            % Look for new COM port
            avrdude_port = arduino_ec.Prefs.searchForComPort;
            if isempty(avrdude_port)
                msgbox('No response from Leonardo''s bootloader.', 'Leonardo flash', 'error');
                return
            end
            avrdude_port = avrdude_port{1};
            fprintf('### Leonardo bootloader found on %s\n', avrdude_port);
        end
       
        avrdude_flags = sprintf('-V -D -F -C %s -p %s -P //./%s -c %s -b %s -U flash:w:%s',...
                    avrdude_conf, mcu, avrdude_port, avrdude_programmer, uploadRate, hexFile);

        cmd = sprintf('%s %s', avrdude, avrdude_flags);
        avrdude_port = origPort;
        % disp(['Running ' cmd]);
         
        disp(['### If your target board has TX and RX LED you should '...
              'see them flashing ... ']);
        
        if isempty(hexDir)
            hexDir = '.';
        end
        origDir = cd(hexDir);
        [s,w] = system(cmd);
        cd(origDir)
        
        disp(w)
        if (s~=0)
            error('RTW:arduino_ec:downloadFailed',...
                  ['Download failed. Check that you have specified the correct '...
                   'Arduino board (using arduino_ec.Prefs.setBoard), and the '... 
                   'correct serial port (using arduino_ec.Prefs.setComPort).']);
        end
        
        lastComPort = avrdude_port;
        lastHexContent = hexContent;

        if ~strcmp(arduino_ec.Prefs.getBoard, 'leonardo')
            % Reset the board; this is needed for PIL to start it properly!
            ResetArduino(avrdude_port);
        end
   
    else
        disp(['Application is already programmed on the Arduino target: ' ...
            'no flash programming is needed'])
        
        % If the application was already programmed, we reset the target.
        ResetArduino(avrdude_port);
    end
end

function ResetArduino(avrdude_port)
    % Opening and closing a serial connection will take the DTR signal
    % low and force a reset of the target.
    s=serial(avrdude_port);
    fopen(s);
    pause(0.25);
    fclose(s);
    delete(s);
end

% Arduino Leonardo is only possible to switch to bootloader mode 
function Reset1200(avrdude_port)
    % Forcing reset using 1200bps open/close
    s=serial(avrdude_port, 'BaudRate', 1200);
    fopen(s);
    pause(0.1);
    fclose(s);
    delete(s);
end
