classdef Prefs
%PREFS gives access to Arduino EC preferences file
%
%   This is an undocumented class. Its methods and properties are likely to
%   change without warning from one release to the next.
%
%   Copyright 2009-2014 The MathWorks, Inc.

    methods (Static, Access=public)
%%
        function setPILSpeed(speed)
            arduino_ec.Prefs.setPref('PILSpeed', speed);
        end

%%
        function speed = getPILSpeed
            speed = arduino_ec.Prefs.getPref('PILSpeed');
            if isempty(speed)
                speed = 9600;    % take default speed
            end
        end
%%
        function setArduinoPath(toolPath)

            if ~exist('toolPath', 'var') || ~ischar(toolPath)
               nl = sprintf('\n');
               error('RTW:arduino_ec:invalidArduinoPath', ...
                      ['Arduino path must be a string, e.g.' nl ...
                       '   arduino_ec.Prefs.setArduinoPath(''c:\\arduino-1.0.5'')']);
            end

            if ~exist(toolPath,'dir')
                error('RTW:arduino_ec:invalidArduinoPath', 'The specified folder (%s) does not exist', toolPath);
            end

            if ~exist(fullfile(toolPath, 'arduino.exe'), 'file')
                error('RTW:arduino_ec:invalidArduinoPath', 'The specified folder (%s) does not contain arduino.exe', toolPath);
            end

            % remove trailing backslashes
            toolPath = regexprep(toolPath, '\\+$', '');

            % Alternate form of path to handle spaces
            altPath = RTW.transformPaths(toolPath, 'pathType', 'alternate');

            arduino_ec.Prefs.setPref('ArduinoPath', altPath);

            % The board data is tied to a specific version of Arduino IDE, so if we change
            % the Arduino path (possibly to a different IDE) the existing data may not be valid
            arduino_ec.Prefs.setPref('ArduinoBoard', []);

            arduino_ec.Prefs.setPref('ArduinoBoardName', '');
        end

%%
        function toolPath = getArduinoPath
            toolPath = arduino_ec.Prefs.getPref('ArduinoPath');
            % check validity of path (in case the folder got deleted between
            % after setArduinoPath and before getArduinoPath)
            if ~exist(toolPath,'dir')
                nl = sprintf('\n');
                error('RTW:arduino_ec:invalidArduinoPath', ...
                      ['Arduino path is unspecified or invalid.' nl ...
                       'Specify a valid path using arduino_ec.Prefs.setArduinoPath, e.g.' nl ...
                       '   arduino_ec.Prefs.setArduinoPath(''c:\\arduino-1.0.5'')']);
            end
        end

%%
        function setBoard(boardLabel)
            boardsFile = fullfile(arduino_ec.Prefs.getArduinoPath(), 'hardware', 'arduino', 'boards.txt');

            if ~exist(boardsFile, 'file')
                nl = sprintf('\n');
                error('RTW:arduino_ec:invalidArduinoPath', ...
                      ['Unable to find board specification file. Ensure that' nl ...
                       'the path to the Arduino IDE is set correctly, e.g.' nl ...
                       '  arduino_ec.Prefs.setArduinoPath(''c:\arduino-1.0.5'')'] );
            end
            boards = arduino_ec.Prefs.parseBoardsFile(boardsFile);
            if isempty(boards)
                error('RTW:arduino_ec:invalidBoardSpecification', ...
                      'Unable to read board specification file (%s)', boardsFile);
            end
            
            parsedLines = regexp(boards, ['^(', boardLabel, '\..+)=([^$]+)$'],'tokens');
            % parsedLines = regexp(rawLines,'^([^=]+)=([^$]+)$','tokens');

            specifiedBoard = {};
            ind = 0;
            for i=1:numel(parsedLines)
                if ~isempty(parsedLines{i})
                    ind = ind + 1;
                    specifiedBoard(ind) = parsedLines{i};
                end
            end

            if isempty(specifiedBoard)
                msg = 'Specified board not found in configuration file';
                error('RTW:arduino_ec:invalidBoardLabel', msg);
            end
            arduino_ec.Prefs.setPref('ArduinoBoard', specifiedBoard);
            arduino_ec.Prefs.setPref('ArduinoBoardName', boardLabel);
        end

%%
        function [boardLabel, allData] = getBoard
            boardLabel = arduino_ec.Prefs.getPref('ArduinoBoardName');
            board = arduino_ec.Prefs.getPref('ArduinoBoard');
            if isempty(board)
                nl = sprintf('\n');
                error('RTW:arduino_ec:noBoardSpecification', ...
                      ['Arduino board is not yet specified. ' nl ...
                       'Specify the board using arduino_ec.Prefs.setBoard, e.g.' nl ...
                       '  arduino_ec.Prefs.setBoard(''uno'') ']);
            end
            if nargout == 2
                allData = board;
            end
        end
%%
        function mcu = getMCU
            mcu = arduino_ec.Prefs.getKey('mcu');
        end
%%
        function cpu = getCPU
            cpu = arduino_ec.Prefs.getKey('cpu');
        end
%%
        function uploadRate = getUploadRate
            uploadRate = arduino_ec.Prefs.getKey('upload.speed$');
        end
%%
        function ret = getKey(key)
            [~, board] = arduino_ec.Prefs.getBoard;
            ret = '';
            key = regexprep(key, '\.', '\\.');
            for i=1:numel(board)
                found = regexp(board{i}{1}, ['.*\.' key]);
                if found
                    ret = board{i}{2};
                    return
                end
            end
        end
%%
        function programmer = getProgrammer
            programmer =  arduino_ec.Prefs.getKey('protocol');
        end
%%
        function cpu_freq = getCpuFrequency
            cpu_freq = arduino_ec.Prefs.getKey('f_cpu');
        end
%%
        function port = getComPort
            port = arduino_ec.Prefs.getPref('ComPort');
            if isempty(port)
                nl = sprintf('\n');
                msg = [
                    'The Arduino serial port must be set and you must have installed' nl ...
                    'the device drivers for your Arduino hardware. ' nl ...
                    ' 1. Install the drivers and connect the Arduino hardware. ' nl ...
                    ' 2. Identify the virtual serial (COM) port. You can do this through' nl ...
                    '    the Windows Device Manager, or by running arduino_ec.Prefs.setComPort' nl ...
                    ' 3. Set the correct COM port using arduino_ec.Prefs.setComPort' ...
                    ];
                error('RTW:arduino_ec:invalidComPort', msg);
            end
        end
%%
        function setComPort(port)
            if ~exist('port', 'var') || ~ischar(port) || isempty(port)
                nl = sprintf('\n');
                error('RTW:arduino_ec:invalidComPort', ...
                      ['Specify the COM port as a string. E.g.: ' nl ...
                       '   arduino_ec.Prefs.setComPort(''COM8'') ']);
            end
            arduino_ec.Prefs.setPref('ComPort', port);
        end
%%
        function ports = searchForComPort(regCmdOutput)
            ports='';

            if ispc
                if nargin < 1
                    regCmd=['reg query '...
                        'HKEY_LOCAL_MACHINE\HARDWARE\DEVICEMAP\SERIALCOMM'];
                    [~,regCmdOutput]=system(regCmd);
                end

                deviceName='\\Device\\(VCP\d|USBSER\d{3})';
                reg_sz = 'REG_SZ';
                portNum = 'COM\d+';
                expr = [deviceName '\s+' reg_sz '\s+(' portNum ')'];
                allPorts=regexp(regCmdOutput,expr,'tokens');
                if ~isempty(allPorts)
                    ports=cell(1, length(allPorts));
                    for j=1:length(allPorts)
                        ports{j}=allPorts{j}{2};
                    end
                end
            end
        end
    end
%%
    methods(Static,Access=private)

        function setPref(prefName, prefValue)
            prefGroup = 'ArduinoGeneric';
            setpref(prefGroup, prefName, prefValue);
        end

        function prefValue = getPref(prefName)
            prefGroup = 'ArduinoGeneric';
            if ispref(prefGroup,prefName)
                prefValue = getpref(prefGroup, prefName);
            else
                prefValue = '';
            end
        end

        function boards = parseBoardsFile(filename)
            boards = {};
            fid = fopen(filename, 'rt');
            if fid < 0,
                return;
            end
            txt = textscan(fid,'%s', 'commentstyle','#','delimiter','\n', 'multipledelimsasone',true);
            fclose(fid);
            boards = txt{1};
        end
    end
end

% LocalWords:  USBSER
